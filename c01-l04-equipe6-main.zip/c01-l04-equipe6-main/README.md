# INF1015 TD4

Pour ce tp, un projet de base est fourni dans le dossier *Exercises/tp4*. L'énoncé nécessaire pour le tp se trouvent sous le dossier *doc*.

 Pour la remise, votre code devra se trouver dans le dossier *Exercises/tp4* sous forme de solution. Le dernier commit du repo avant la date de remise sera utilisé pour la correction. 
 
 **Assurez-vous que vos fichiers ont été push sur votre répertoire avant la remise** 
 
 **Date de remise:** Dimanche 5 juin - 23h59

18.75/20

-0.25 problème d'affichage de couleur dans les transitions

-0.25 attribut nAllie_

-0.25 manque const pour les getters

-0.5 affichage VillainHeros"

![image](https://user-images.githubusercontent.com/47032065/172491213-8c23922b-075a-4217-acf3-8a0ffcb19b3a.png)
