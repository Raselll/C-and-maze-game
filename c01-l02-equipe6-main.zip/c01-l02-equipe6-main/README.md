# INF1015 TD2

Pour ce tp, un projet de base est fourni dans le dossier *Exercises*. L'énoncé ainsi que de la documentation nécessaire pour le tp se trouvent sous le dossier *doc*.

 Pour la remise, votre code devra se trouver dans le dossier *Exercises* sous forme de solution. Le dernier commit du repo avant la date de remise sera utilisé pour la correction. 
 
 **Assurez-vous que vos fichiers ont été push sur votre répertoire avant la remise** 
 
 **Date de remise:** Dimanche 22 mai - 23h59
 
Equipe6	17.75/20.00

* -0.25 entête incomplète
* -0.25 Le nom des cpp n'est pas le même que celui des hpp

P1 
* -0.25 findDesigner erreur de logique
* -0.25 cout lireDesigner
* -0.25 fuite laissé dans le main

P2
* -0.25 abréviation Nb dans un nom de fonction
* -0.25 nom de variable A
* -0.25 nom de variable commencant par une majuscule
* -0.25 else remove de ListeDeveloppeur"
![image](https://user-images.githubusercontent.com/47032065/169940019-c45e967b-532b-41fe-acfe-c41380d05936.png)
