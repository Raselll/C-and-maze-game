﻿#pragma once
#include "Designer.hpp"

struct ListeDesigners
{
	int nElements;
	int capacite;
	Designer** elements;
};
