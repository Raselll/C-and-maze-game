﻿#pragma once
#include <iostream>
#include <memory>
#include <cassert>
#include "gsl/span"
#include "cppitertools/range.hpp"

template <typename T>
class Liste
{
public:
	Liste() { nElements_ = 0; capacite_ = 0; }
	std::shared_ptr<T>& operator[] (int index) { return elements_[index]; }
	const std::shared_ptr<T>& operator[] (int index) const { return elements_[index]; }
	Liste(const Liste<T>& other)
	{
		changeCapacity(other.getCapacite());
		for (int i : iter::range(other.size()))
			addElems(other[i]);
	}

	void addElems(std::shared_ptr<T> elements)
	{
		if (nElements_ >= capacite_)
			changeCapacity((capacite_ + 1) * 2);
		elements_[nElements_++] = std::move(elements);
	}

	unsigned size() const { return nElements_; }
	unsigned getCapacite() const  { return capacite_; }

	void changeCapacity(unsigned newGameListCapacity)
	{
		assert(newGameListCapacity >= nElements_);
		auto newElements = std::make_unique<std::shared_ptr<T>[]>(newGameListCapacity);
		for (int i : iter::range(nElements_))
			newElements[i] = elements_[i];

		elements_ = std::move(newElements);
		capacite_ = newGameListCapacity;
	}

	std::shared_ptr<T> findByCriteria(const std::function<bool(const T&)>& criteria) const {
		for (int i : iter::range(nElements_)) 
			if (criteria(*elements_[i]))
				return elements_[i];
		return nullptr;
	}

private:
	unsigned nElements_;
	unsigned capacite_;
	std::unique_ptr<std::shared_ptr<T>[]> elements_;
};
