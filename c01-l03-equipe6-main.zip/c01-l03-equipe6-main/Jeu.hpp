#pragma once
#include "Liste.hpp"
#include "Concepteur.hpp"
#include <string>
#include <memory>
#include <functional>

class Jeu
{
public:
	Jeu() { titre_ = "   ", anneeSortie_ = 0, developpeur_ = "   "; }
	Jeu(std::string title, unsigned yearOfRelease, std::string developper)
	{
		titre_ = title;
		anneeSortie_ = yearOfRelease;
		developpeur_ = developper;
	}
	const std::string& getTitre() const     { return titre_; }
	void setTitre(const std::string& titre) { titre_ = titre; }
	unsigned getAnneeSortie() const         { return anneeSortie_; }
	void setAnneeSortie(unsigned annee)     { anneeSortie_ = annee; }
	const std::string& getDeveloppeur() const { return developpeur_; }
	void setDeveloppeur(const std::string& developpeur) { developpeur_ = developpeur; }

	Liste<Concepteur>& getConceptor() { return elements_; }
	const Liste<Concepteur>& getConceptor() const { return elements_; }

	std::shared_ptr<Concepteur> findConceptor(const std::function<bool(const Concepteur&)> criteria) { return elements_.findByCriteria(criteria); }

private:
	std::string titre_;
	unsigned anneeSortie_;
	std::string developpeur_;
	Liste<Concepteur>elements_;
};
