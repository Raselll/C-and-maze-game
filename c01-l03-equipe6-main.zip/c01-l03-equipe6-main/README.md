# INF1015 TD3

Pour ce tp, un projet de base est fourni dans le dossier *Exercises/tp3*. Aussi, pour vous aidez, le solutionnaire du tp2 vous est fourni dans le dossier *Exercises/solutionnaire-tp2*. L'énoncé nécessaire pour le tp se trouvent sous le dossier *doc*.

 Pour la remise, votre code devra se trouver dans le dossier *Exercises/tp3* sous forme de solution. Le dernier commit du repo avant la date de remise sera utilisé pour la correction. 
 
 **Assurez-vous que vos fichiers ont été push sur votre répertoire avant la remise** 
 
 **Date de remise:** Dimanche 29 mai - 23h59

17.25/20

-1 non respect du format de remise

-0.25 Manque l'entête dans certains fichiers

-0.5 mélange anglais/français un peu partout

-0.25 method addElems

-0.25 double appel de fonction

-0.25 cout non enlevé

-0.25 affichage concepteur
