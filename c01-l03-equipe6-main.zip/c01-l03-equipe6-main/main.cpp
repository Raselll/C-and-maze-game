﻿/**
* Programme qui initialise une liste de jeux. Surchages des opérateurs << permettent l'affichage des listes, passées avec un type générique.
* \file   main.cpp
* \author Bakir, Farid (1908977), Chowdhury, Rasel (2143023) et Tao, Tristan (1951367)
* \date   29 mai 2022
* Créé le 23 mai 2022
*/

#include "bibliotheque_cours.hpp"
#include "verification_allocation.hpp"
#include "Liste.hpp"
#include "Concepteur.hpp"
#include "Jeu.hpp"
#include "lectureFichierJeux.hpp"
#include <iostream>
#include <fstream>
using namespace std;

template <typename T>
ostream& operator << (ostream& os, const Liste<T>& list)
{
	for (int i = 0; i < list.size(); i++) 
		os << *(list[i]) << "\n";
	
	return os;
}

ostream& operator << (ostream& os, const Jeu& game)
{
	os << "Title of the game : " << game.getTitre() << "\n";
	os << "Year of release of the game: " << game.getAnneeSortie() << "\n";
	os << "Developper of the game :" << game.getDeveloppeur() << "\n";
	return os;
}

ostream& operator << (ostream& os, const Concepteur& conceptor)
{
	os << "Name of the conceptor : " << conceptor.getNom() << "\n";
	os << "Date of birth of the conceptor : " << conceptor.getAnneeNaissance() << "\n";
	os << "Country of the developper : " << conceptor.getPays() << "\n";
	return os;
}

int main(int argc, char** argv)
{
	#pragma region "Bibliothèque du cours"
	// Permet sous Windows les "ANSI escape code" pour changer de couleur
	// https://en.wikipedia.org/wiki/ANSI_escape_code ; les consoles Linux/Mac
	// les supportent normalement par défaut.
	bibliotheque_cours::activerCouleursAnsi(); 
	#pragma endregion
	
	Liste<Jeu> gameList = creerListeJeux("jeux.bin");
	static const string ligneSeparation = "\n\033[92m"
		"══════════════════════════════════════════════════════════════════════════"
		"\033[0m\n";

	cout << ligneSeparation << gameList;
	ofstream("sortie.txt") << gameList;

	cout << ligneSeparation << "\n";
	cout << "\033[92m" << "Testing game list capacity and size : " << "\033[0m" << "\n";
	cout << "The number of elements is : " << gameList.size() << "\n";
	cout << "The capacity of the list is :" << gameList.getCapacite() << "\n";
	cout << "\n";

	cout << "\033[92m" << "Testing the title and the name of the conceptor : " << "\033[0m" << "\n";
	cout << "The title of the game at index 2 is : " << gameList[2]->getTitre() << "\n";
	cout << "The name of the conceptor at the first index is : " << gameList[2]->getConceptor()[1]->getNom() << "\n";
	cout << "\n";

	string nom = "Yoshinori Kitase";
	auto nameCriteria = [&nom](Concepteur conceptor) { return conceptor.getNom() == nom; };
	auto ptrYoshinori = gameList[0]->findConceptor(nameCriteria);
	cout << "\033[92m" << "Testing Yoshinori kitase : " << "\033[0m" << "\n";
	cout << "Yoshinori Kitase is in game 0 and 1  " << "\n";
	if (ptrYoshinori->getAnneeNaissance() == 1966)
		cout << "The conceptor's birth year is 1966 " << "\n";
	cout << "\n";

	cout << "\033[92m" << "Testing copy functions : " << "\033[0m" << "\n";
	Jeu gameCopy = *gameList[2];
	gameCopy.getConceptor()[2] = gameList[0]->getConceptor()[0];
	cout << "The list of conceptors of the game at index 2 is : " << "\n";
	for (int i : iter::range(gameList[2]->getConceptor().size())) {
		cout << "Name : " << gameList[2]->getConceptor()[i]->getNom() << "\n";
		cout << "Year of birth : " << gameList[2]->getConceptor()[i]->getAnneeNaissance() << "\n";
		cout << "Country : " << gameList[2]->getConceptor()[i]->getPays() << "\n";
	}
	cout << "The list of conceptors of the copied game is : " << "\n";
	for (int i : iter::range(gameCopy.getConceptor().size())) {
		cout << "Name : " << gameCopy.getConceptor()[i]->getNom() << "\n";
		cout << "Year of birth : " << gameCopy.getConceptor()[i]->getAnneeNaissance() << "\n";
		cout << "Country : " << gameCopy.getConceptor()[i]->getPays() << "\n";
	}
	if (gameCopy.getConceptor()[0] == gameList[2]->getConceptor()[0])
		cout << "The address of the first conceptor is the same in both lists." << "\n";
}