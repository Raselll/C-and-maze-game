/**
* D�finition des fonctions de lecture et de modification des listes de jeux.
* \file   lectureFichierJeux.cpp
* \author Bakir, Farid (1908977), Chowdhury, Rasel (2143023) et Tao, Tristan (1951367)
* \date   29 mai 2022
* Cr�� le 23 mai 2022
*/

#include "lectureFichierJeux.hpp"
#include <fstream>
#include "cppitertools/range.hpp"
using namespace std;

#pragma region "Fonctions de lecture de base"
UInt8 lireUint8(istream& fichier)
{
	UInt8 valeur = 0;
	fichier.read(reinterpret_cast<char*>(&valeur), sizeof(valeur));
	return valeur;
}

UInt16 lireUint16(istream& fichier)
{
	UInt16 valeur = 0;
	fichier.read(reinterpret_cast<char*>(&valeur), sizeof(valeur));
	return valeur;
}

string lireString(istream& fichier)
{
	string texte;
	texte.resize(lireUint16(fichier));
	fichier.read(reinterpret_cast<char*>(&texte[0]), streamsize(sizeof(texte[0])) * texte.length());
	return texte;
}
#pragma endregion

shared_ptr<Concepteur> chercherConcepteur(Liste<Jeu>& gameList, string nom)
{
	auto nameCriteria = [&nom](Concepteur conceptor) { return conceptor.getNom() == nom; };
	for (int i : iter::range(gameList.size())) {
		if (gameList[i]->findConceptor(nameCriteria) != nullptr)
			return gameList[i]->findConceptor(nameCriteria);
	}
	return nullptr;
}

shared_ptr<Concepteur> lireConcepteur(Liste<Jeu>& gameList, istream& file)
{
	string nom              = lireString(file);
	unsigned anneeNaissance = lireUint16(file);
	string pays             = lireString(file);

	//TODO: Compl�ter la fonction (�quivalent de lireDesigner du TD2).
	auto conceptorPtr = chercherConcepteur(gameList, nom);
	if (conceptorPtr == nullptr)
		conceptorPtr = make_shared<Concepteur>(nom, anneeNaissance, pays);
	cout << "C: " << nom << endl;  //TODO: Enlever cet affichage temporaire servant � voir que le code fourni lit bien les jeux.
	return conceptorPtr;
}

shared_ptr<Jeu> lireJeu(istream& file, Liste<Jeu>& gameList)
{
	string titre = lireString(file);
	unsigned anneeSortie = lireUint16(file);
	string developpeur = lireString(file);
	unsigned nConcepteurs = lireUint8(file);

	//TODO: Compl�ter la fonction (�quivalent de lireJeu du TD2).
	auto gamePtr = make_shared<Jeu>(titre, anneeSortie, developpeur);
	for (unsigned int i = 0; i < nConcepteurs; i++)
		gamePtr->getConceptor().addElems(lireConcepteur(gameList, file));
	cout << "J: " << titre << endl;  //TODO: Enlever cet affichage temporaire servant � voir que le code fourni lit bien les jeux.
	
	return gamePtr;
}

Liste<Jeu> creerListeJeux(const string& fileName)
{
	ifstream f(fileName, ios::binary);
	f.exceptions(ios::failbit);
	int nElements = lireUint16(f);
	//TODO: Compl�ter la fonction.
	Liste<Jeu> listeJeux;
	for (int i : iter::range(nElements))
		listeJeux.addElems(lireJeu(f, listeJeux));
	return listeJeux;
}
